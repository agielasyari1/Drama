'use client';

import { useState, useEffect, useCallback } from 'react';
import useSWR from 'swr';
import { getWatchProgress, updateWatchProgress } from '@/lib/api';
import type { WatchProgress } from '@/types';

export function useWatchHistory() {
    const { data, error, isLoading, mutate } = useSWR<WatchProgress[]>(
        'watch-history',
        getWatchProgress,
        {
            revalidateOnFocus: false,
        }
    );

    const updateProgress = useCallback(async (progress: WatchProgress) => {
        await updateWatchProgress(progress);
        mutate();
    }, [mutate]);

    return {
        history: data || [],
        isLoading,
        error,
        updateProgress,
        refetch: mutate,
    };
}

// Get progress for a specific episode
export function useEpisodeProgress(episodeId: string | null) {
    const { history } = useWatchHistory();

    const progress = episodeId
        ? history.find(p => p.episodeId === episodeId)
        : null;

    return {
        progress: progress?.progress || 0,
        lastWatched: progress?.lastWatched || null,
    };
}

// Video player state hook
export function useVideoPlayer(initialProgress = 0) {
    const [isPlaying, setIsPlaying] = useState(false);
    const [currentTime, setCurrentTime] = useState(0);
    const [duration, setDuration] = useState(0);
    const [progress, setProgress] = useState(initialProgress);
    const [isFullscreen, setIsFullscreen] = useState(false);
    const [quality, setQuality] = useState<'auto' | '720p' | '480p' | '360p'>('auto');
    const [showControls, setShowControls] = useState(true);

    // Auto-hide controls after 3 seconds
    useEffect(() => {
        if (isPlaying && showControls) {
            const timer = setTimeout(() => setShowControls(false), 3000);
            return () => clearTimeout(timer);
        }
    }, [isPlaying, showControls]);

    const togglePlay = useCallback(() => {
        setIsPlaying(prev => !prev);
        setShowControls(true);
    }, []);

    const skip = useCallback((seconds: number) => {
        setCurrentTime(prev => {
            const newTime = Math.max(0, Math.min(duration, prev + seconds));
            setProgress((newTime / duration) * 100);
            return newTime;
        });
        setShowControls(true);
    }, [duration]);

    const seek = useCallback((time: number) => {
        setCurrentTime(time);
        setProgress((time / duration) * 100);
        setShowControls(true);
    }, [duration]);

    const toggleFullscreen = useCallback(() => {
        setIsFullscreen(prev => !prev);
    }, []);

    return {
        isPlaying,
        currentTime,
        duration,
        progress,
        isFullscreen,
        quality,
        showControls,
        setIsPlaying,
        setCurrentTime,
        setDuration,
        setProgress,
        setQuality,
        setShowControls,
        togglePlay,
        skip,
        seek,
        toggleFullscreen,
    };
}
