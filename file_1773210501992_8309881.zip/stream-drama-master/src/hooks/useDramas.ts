import useSWR from 'swr';
import { getHomeFeed, getTrendingDramas, getNewReleases, getDramaById, getDramasByGenre } from '@/lib/api';
import type { Drama, CarouselSection } from '@/types';

// Home feed sections
export function useHomeFeed() {
    return useSWR<CarouselSection[]>('home-feed', getHomeFeed, {
        revalidateOnFocus: false,
        dedupingInterval: 60000, // 1 minute
    });
}

// Trending dramas
export function useTrendingDramas() {
    return useSWR<Drama[]>('trending', getTrendingDramas, {
        revalidateOnFocus: false,
    });
}

// New releases
export function useNewReleases() {
    return useSWR<Drama[]>('new-releases', getNewReleases, {
        revalidateOnFocus: false,
    });
}

// Single drama by ID
export function useDrama(id: string | null) {
    return useSWR<Drama | null>(
        id ? ['drama', id] : null,
        () => (id ? getDramaById(id) : null),
        {
            revalidateOnFocus: false,
        }
    );
}

// Dramas by genre
export function useDramasByGenre(genre: string | null) {
    return useSWR<Drama[]>(
        genre ? ['genre', genre] : null,
        () => (genre ? getDramasByGenre(genre) : []),
        {
            revalidateOnFocus: false,
        }
    );
}
