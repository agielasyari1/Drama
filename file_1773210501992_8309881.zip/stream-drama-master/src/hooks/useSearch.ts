'use client';

import { useState, useEffect, useCallback } from 'react';
import useSWR from 'swr';
import { searchDramas } from '@/lib/api';
import type { SearchResult } from '@/types';

export function useSearch(initialQuery = '') {
    const [query, setQuery] = useState(initialQuery);
    const [debouncedQuery, setDebouncedQuery] = useState(initialQuery);

    // Debounce the search query
    useEffect(() => {
        const timer = setTimeout(() => {
            setDebouncedQuery(query);
        }, 300);

        return () => clearTimeout(timer);
    }, [query]);

    // SWR for the actual search
    const { data, error, isLoading, mutate } = useSWR<SearchResult>(
        debouncedQuery.trim() ? ['search', debouncedQuery] : null,
        () => searchDramas(debouncedQuery),
        {
            revalidateOnFocus: false,
            dedupingInterval: 5000,
        }
    );

    const clearSearch = useCallback(() => {
        setQuery('');
        setDebouncedQuery('');
    }, []);

    return {
        query,
        setQuery,
        results: data?.dramas || [],
        total: data?.total || 0,
        isLoading: isLoading && debouncedQuery.length > 0,
        error,
        clearSearch,
        refetch: mutate,
    };
}

// Recent searches hook (localStorage backed)
export function useRecentSearches() {
    const [searches, setSearches] = useState<string[]>([]);

    useEffect(() => {
        const stored = localStorage.getItem('recentSearches');
        if (stored) {
            try {
                setSearches(JSON.parse(stored));
            } catch {
                setSearches([]);
            }
        }
    }, []);

    const addSearch = useCallback((term: string) => {
        if (!term.trim()) return;

        setSearches(prev => {
            const filtered = prev.filter(s => s !== term);
            const updated = [term, ...filtered].slice(0, 10);
            localStorage.setItem('recentSearches', JSON.stringify(updated));
            return updated;
        });
    }, []);

    const removeSearch = useCallback((term: string) => {
        setSearches(prev => {
            const updated = prev.filter(s => s !== term);
            localStorage.setItem('recentSearches', JSON.stringify(updated));
            return updated;
        });
    }, []);

    const clearSearches = useCallback(() => {
        setSearches([]);
        localStorage.removeItem('recentSearches');
    }, []);

    return {
        searches,
        addSearch,
        removeSearch,
        clearSearches,
    };
}
