'use client';

import { useState, useEffect, useRef } from 'react';
import { Search, X, Clock, TrendingUp } from 'lucide-react';
import { useSearch, useRecentSearches } from '@/hooks/useSearch';
import { DramaCardCompact } from '@/components/ui/DramaCard';
import { SearchResultsSkeleton } from '@/components/ui/Skeleton';
import { cn } from '@/lib/utils';

const genreFilters = ['Romance', 'Action', 'Comedy', 'Thriller', 'Fantasy', 'Medical', 'Historical'];

export default function SearchPage() {
    const inputRef = useRef<HTMLInputElement>(null);
    const { query, setQuery, results, isLoading, clearSearch } = useSearch();
    const { searches: recentSearches, addSearch, removeSearch, clearSearches } = useRecentSearches();
    const [selectedGenre, setSelectedGenre] = useState<string | null>(null);

    // Focus input on mount
    useEffect(() => {
        inputRef.current?.focus();
    }, []);

    // Handle search submission
    const handleSearch = (term: string) => {
        setQuery(term);
        addSearch(term);
    };

    const hasQuery = query.trim().length > 0;
    const showRecent = !hasQuery && recentSearches.length > 0;
    const showGenres = !hasQuery;

    return (
        <div className="min-h-screen p-4 pt-2">
            {/* Search Input */}
            <div className="sticky top-0 z-10 bg-background pb-3">
                <div className="relative">
                    <Search
                        size={20}
                        className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none"
                    />
                    <input
                        ref={inputRef}
                        type="text"
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && query.trim() && addSearch(query)}
                        placeholder="Search dramas, actors, genres..."
                        className="w-full h-12 pl-10 pr-10 bg-card text-foreground rounded-xl border border-border focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all placeholder:text-muted-foreground"
                    />
                    {hasQuery && (
                        <button
                            onClick={clearSearch}
                            className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-muted-foreground hover:text-foreground"
                            aria-label="Clear search"
                        >
                            <X size={18} />
                        </button>
                    )}
                </div>
            </div>

            {/* Recent Searches */}
            {showRecent && (
                <section className="mb-6 animate-fadeIn">
                    <div className="flex items-center justify-between mb-3">
                        <h2 className="text-sm font-semibold text-muted-foreground flex items-center gap-2">
                            <Clock size={14} />
                            Recent Searches
                        </h2>
                        <button
                            onClick={clearSearches}
                            className="text-xs text-muted hover:text-foreground transition-colors"
                        >
                            Clear all
                        </button>
                    </div>
                    <div className="flex flex-wrap gap-2">
                        {recentSearches.map(term => (
                            <button
                                key={term}
                                onClick={() => handleSearch(term)}
                                className="group flex items-center gap-1 px-3 py-1.5 bg-card hover:bg-secondary rounded-full text-sm transition-colors"
                            >
                                <span>{term}</span>
                                <X
                                    size={14}
                                    className="text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity"
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        removeSearch(term);
                                    }}
                                />
                            </button>
                        ))}
                    </div>
                </section>
            )}

            {/* Genre Filters */}
            {showGenres && (
                <section className="mb-6 animate-fadeIn">
                    <h2 className="text-sm font-semibold text-muted-foreground flex items-center gap-2 mb-3">
                        <TrendingUp size={14} />
                        Popular Genres
                    </h2>
                    <div className="flex flex-wrap gap-2">
                        {genreFilters.map(genre => (
                            <button
                                key={genre}
                                onClick={() => {
                                    setSelectedGenre(genre);
                                    handleSearch(genre);
                                }}
                                className={cn(
                                    'px-4 py-2 rounded-full text-sm font-medium transition-all',
                                    selectedGenre === genre
                                        ? 'bg-primary text-primary-foreground'
                                        : 'bg-card hover:bg-secondary text-foreground'
                                )}
                            >
                                {genre}
                            </button>
                        ))}
                    </div>
                </section>
            )}

            {/* Search Results */}
            {hasQuery && (
                <section className="animate-fadeIn">
                    {isLoading ? (
                        <SearchResultsSkeleton />
                    ) : results.length > 0 ? (
                        <>
                            <p className="text-sm text-muted-foreground mb-4">
                                Found {results.length} result{results.length !== 1 ? 's' : ''} for &quot;{query}&quot;
                            </p>
                            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3">
                                {results.map(drama => (
                                    <DramaCardCompact key={drama.id} drama={drama} />
                                ))}
                            </div>
                        </>
                    ) : (
                        <div className="text-center py-12">
                            <p className="text-muted-foreground">No results found for &quot;{query}&quot;</p>
                            <p className="text-sm text-muted mt-1">Try different keywords</p>
                        </div>
                    )}
                </section>
            )}
        </div>
    );
}
