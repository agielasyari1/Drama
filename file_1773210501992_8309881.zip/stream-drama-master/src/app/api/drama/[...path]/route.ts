// Next.js API route to proxy DramaBox API requests
// This runs server-side where we have access to the API token

import { NextRequest, NextResponse } from 'next/server';

const API_BASE = 'https://api.sansekai.my.id/api';
const API_TOKEN = process.env.NEXT_PUBLIC_DRAMABOX_TOKEN || '';

export async function GET(
    request: NextRequest,
    { params }: { params: Promise<{ path: string[] }> }
) {
    const { path } = await params;
    const apiPath = path.join('/');
    const searchParams = request.nextUrl.searchParams;

    // Build the full API URL with query parameters
    const url = new URL(`${API_BASE}/${apiPath}`);
    searchParams.forEach((value, key) => {
        url.searchParams.append(key, value);
    });

    try {
        const response = await fetch(url.toString(), {
            method: 'GET',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                ...(API_TOKEN && { 'Authorization': `Bearer ${API_TOKEN}` }),
            },
        });

        if (!response.ok) {
            return NextResponse.json(
                { error: `API Error: ${response.status}` },
                { status: response.status }
            );
        }

        const data = await response.json();
        return NextResponse.json(data);
    } catch (error) {
        console.error('Proxy error:', error);
        return NextResponse.json(
            { error: 'Failed to fetch data' },
            { status: 500 }
        );
    }
}

export async function POST(
    request: NextRequest,
    { params }: { params: Promise<{ path: string[] }> }
) {
    const { path } = await params;
    const apiPath = path.join('/');
    const searchParams = request.nextUrl.searchParams;

    // Build the full API URL
    const url = new URL(`${API_BASE}/${apiPath}`);
    searchParams.forEach((value, key) => {
        url.searchParams.append(key, value);
    });

    try {
        const body = await request.json();

        const response = await fetch(url.toString(), {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                ...(API_TOKEN && { 'Authorization': `Bearer ${API_TOKEN}` }),
            },
            body: JSON.stringify(body),
        });

        if (!response.ok) {
            return NextResponse.json(
                { error: `API Error: ${response.status}` },
                { status: response.status }
            );
        }

        const data = await response.json();
        return NextResponse.json(data);
    } catch (error) {
        console.error('Proxy error:', error);
        return NextResponse.json(
            { error: 'Failed to fetch data' },
            { status: 500 }
        );
    }
}
