'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import useSWR from 'swr';
import VideoPlayer from '@/components/player/VideoPlayer';
import { getEpisodeById, getEpisodesByDramaId, updateWatchProgress, getDramaById } from '@/lib/api';
import { Skeleton } from '@/components/ui/Skeleton';
import type { Episode, WatchProgress, Drama } from '@/types';

interface WatchPageClientProps {
    episodeId: string;
}

export default function WatchPageClient({ episodeId }: WatchPageClientProps) {
    const router = useRouter();
    const [hasNextEpisode, setHasNextEpisode] = useState(false);
    const [nextEpisodeId, setNextEpisodeId] = useState<string | null>(null);
    const [hasPrevEpisode, setHasPrevEpisode] = useState(false);
    const [prevEpisodeId, setPrevEpisodeId] = useState<string | null>(null);

    // Common SWR config to prevent rate limiting
    const swrConfig = {
        revalidateOnFocus: false,
        revalidateIfStale: false,
        shouldRetryOnError: false,
        dedupingInterval: 60000, // 1 minute
    };

    // Fetch current episode
    const { data: episode, isLoading } = useSWR<Episode | null>(
        ['episode', episodeId],
        () => getEpisodeById(episodeId),
        swrConfig
    );

    useEffect(() => {
        if (episode) {
            console.log('Fetched episode:', episode.id, 'Video URL:', episode.videoUrl);
        }
    }, [episode]);

    // Fetch drama details
    const { data: drama } = useSWR<Drama | null>(
        episode ? ['drama', episode.dramaId] : null,
        () => episode ? getDramaById(episode.dramaId) : Promise.resolve(null),
        swrConfig
    );

    // Fetch all episodes to find next
    const { data: allEpisodes } = useSWR<Episode[]>(
        episode ? ['drama-episodes', episode.dramaId] : null,
        () => episode ? getEpisodesByDramaId(episode.dramaId) : Promise.resolve([]),
        swrConfig
    );

    // Find next/prev episode
    useEffect(() => {
        if (episode && allEpisodes) {
            const currentIndex = allEpisodes.findIndex(e => e.id === episodeId);

            // Next Episode
            if (currentIndex >= 0 && currentIndex < allEpisodes.length - 1) {
                setHasNextEpisode(true);
                setNextEpisodeId(allEpisodes[currentIndex + 1].id);
            } else {
                setHasNextEpisode(false);
                setNextEpisodeId(null);
            }

            // Prev Episode
            if (currentIndex > 0) {
                setHasPrevEpisode(true);
                setPrevEpisodeId(allEpisodes[currentIndex - 1].id);
            } else {
                setHasPrevEpisode(false);
                setPrevEpisodeId(null);
            }
        }
    }, [episode, allEpisodes, episodeId]);

    // Handle progress update
    const handleProgress = async (progress: number) => {
        if (!episode) return;

        // Only update every 5% to reduce API calls
        if (progress % 5 < 1) {
            await updateWatchProgress({
                episodeId: episode.id,
                dramaId: episode.dramaId,
                progress,
                lastWatched: new Date().toISOString(),
            }, drama);
        }
    };

    // Handle next episode
    const handleNextEpisode = () => {
        if (nextEpisodeId) {
            router.push(`/watch/${nextEpisodeId}`);
        }
    };

    // Handle prev episode
    const handlePrevEpisode = () => {
        if (prevEpisodeId) {
            router.push(`/watch/${prevEpisodeId}`);
        }
    };

    // Handle back navigation
    const handleBack = () => {
        if (episode) {
            router.push(`/drama/${episode.dramaId}`);
        } else {
            router.back();
        }
    };

    if (isLoading) {
        return (
            <div className="fixed inset-0 bg-black flex items-center justify-center">
                <Skeleton className="w-full h-full" />
            </div>
        );
    }

    if (!episode) {
        return (
            <div className="fixed inset-0 bg-black flex items-center justify-center text-white">
                <p>Episode not found</p>
            </div>
        );
    }

    return (
        <div className="fixed inset-0 bg-black">
            <VideoPlayer
                videoUrl={episode.videoUrl}
                title={episode.title}
                episodeNumber={episode.number}
                dramaTitle={drama?.title || ""}
                onProgress={handleProgress}
                initialProgress={0}
                onNextEpisode={handleNextEpisode}
                hasNextEpisode={hasNextEpisode}
                onPrevEpisode={handlePrevEpisode}
                hasPrevEpisode={hasPrevEpisode}
                onBack={handleBack}
            />
        </div>
    );
}
