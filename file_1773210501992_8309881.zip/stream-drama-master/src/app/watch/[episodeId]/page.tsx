import { Suspense } from 'react';
import WatchPageClient from './WatchPageClient';
import { getEpisodeById } from '@/lib/api';

interface WatchPageProps {
    params: Promise<{ episodeId: string }>;
}

export async function generateMetadata({ params }: WatchPageProps) {
    const { episodeId } = await params;
    const episode = await getEpisodeById(episodeId, false);

    if (!episode) {
        return { title: 'Watch - StreamDrama' };
    }

    return {
        title: `Episode ${episode.number} - ${episode.title}`,
        description: episode.synopsis,
    };
}

export default async function WatchPage({ params }: WatchPageProps) {
    const { episodeId } = await params;

    return (
        <Suspense fallback={<div className="fixed inset-0 bg-black" />}>
            <WatchPageClient episodeId={episodeId} />
        </Suspense>
    );
}
