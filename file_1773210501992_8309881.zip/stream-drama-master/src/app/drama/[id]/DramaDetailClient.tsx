'use client';

import { useState, useEffect } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Play, Plus, Check, ChevronDown, Share2 } from 'lucide-react';
import Button from '@/components/ui/Button';
import CastInfo, { DramaMeta } from '@/components/drama/CastInfo';
import EpisodeList from '@/components/drama/EpisodeList';
import type { Drama, Episode } from '@/types';
import { cn } from '@/lib/utils';

import { isInMyList, addToMyList, removeFromMyList } from '@/lib/api';

interface DramaDetailClientProps {
    drama: Drama;
    episodes: Episode[];
}

export default function DramaDetailClient({ drama, episodes }: DramaDetailClientProps) {
    const [inList, setInList] = useState(false);
    const [showFullSynopsis, setShowFullSynopsis] = useState(false);

    useEffect(() => {
        setInList(isInMyList(drama.id));
    }, [drama.id]);

    const toggleMyList = () => {
        if (inList) {
            removeFromMyList(drama.id);
            setInList(false);
        } else {
            addToMyList(drama);
            setInList(true);
        }
    };

    const firstEpisode = episodes[0];

    return (
        <div className="min-h-screen pb-8">
            {/* Backdrop Header */}
            <div className="relative w-full aspect-[16/10] sm:aspect-[16/9]">
                <Image
                    src={drama.backdropUrl}
                    alt={drama.title}
                    fill
                    className="object-cover"
                    priority
                    sizes="100vw"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/70 to-transparent" />
            </div>

            {/* Content */}
            <div className="relative -mt-32 px-4 space-y-6">
                {/* Title & Actions */}
                <div className="space-y-4">
                    <h1 className="text-2xl sm:text-3xl font-bold text-white drop-shadow-lg">
                        {drama.title}
                    </h1>

                    {drama.originalTitle && (
                        <p className="text-sm text-white/70">{drama.originalTitle}</p>
                    )}

                    {/* Meta Info */}
                    <DramaMeta
                        year={drama.year}
                        country={drama.country}
                        episodes={drama.episodes}
                        status={drama.status}
                        rating={drama.rating}
                    />

                    {/* Action Buttons */}
                    <div className="flex items-center gap-3">
                        {firstEpisode && (
                            <Link href={`/watch/${firstEpisode.id}`} className="flex-1 sm:flex-none">
                                <Button variant="primary" size="lg" className="w-full sm:w-auto gap-2">
                                    <Play size={18} className="fill-white" />
                                    Play
                                </Button>
                            </Link>
                        )}

                        <Button
                            variant="secondary"
                            size="icon"
                            className="h-12 w-12"
                            onClick={toggleMyList}
                            aria-label={inList ? 'Remove from My List' : 'Add to My List'}
                        >
                            {inList ? (
                                <Check size={20} className="text-primary" />
                            ) : (
                                <Plus size={20} />
                            )}
                        </Button>

                        <Button
                            variant="secondary"
                            size="icon"
                            className="h-12 w-12"
                            aria-label="Share"
                        >
                            <Share2 size={20} />
                        </Button>
                    </div>
                </div>

                {/* Genre Tags */}
                <div className="flex flex-wrap gap-2">
                    {drama.genre.map(g => (
                        <Link
                            key={g}
                            href={`/search?genre=${g}`}
                            className="px-3 py-1 bg-card hover:bg-secondary text-sm rounded-full transition-colors"
                        >
                            {g}
                        </Link>
                    ))}
                </div>

                {/* Synopsis */}
                <section className="space-y-2">
                    <h2 className="text-lg font-bold">Synopsis</h2>
                    <p
                        className={cn(
                            'text-muted-foreground leading-relaxed cursor-pointer',
                            !showFullSynopsis && 'line-clamp-3'
                        )}
                        onClick={() => setShowFullSynopsis(!showFullSynopsis)}
                    >
                        {drama.synopsis}
                    </p>
                    {!showFullSynopsis && (
                        <button
                            onClick={() => setShowFullSynopsis(true)}
                            className="text-primary text-sm font-medium flex items-center gap-1"
                        >
                            Read more <ChevronDown size={14} />
                        </button>
                    )}
                </section>

                {/* Cast */}
                <CastInfo cast={drama.cast} />

                {/* Episodes */}
                <EpisodeList episodes={episodes} />
            </div>
        </div>
    );
}
