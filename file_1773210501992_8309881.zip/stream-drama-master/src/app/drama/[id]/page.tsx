import { Suspense } from 'react';
import { notFound } from 'next/navigation';
import DramaDetailClient from './DramaDetailClient';
import { getDramaById, getEpisodesByDramaId } from '@/lib/api';
import { EpisodeListSkeleton } from '@/components/ui/Skeleton';

interface DramaPageProps {
    params: Promise<{ id: string }>;
}

export async function generateMetadata({ params }: DramaPageProps) {
    const { id } = await params;
    const drama = await getDramaById(id);

    if (!drama) {
        return { title: 'Drama Not Found' };
    }

    return {
        title: drama.title,
        description: drama.synopsis,
        openGraph: {
            title: drama.title,
            description: drama.synopsis,
            images: [drama.backdropUrl],
        },
    };
}

export default async function DramaPage({ params }: DramaPageProps) {
    const { id } = await params;
    const [drama, episodes] = await Promise.all([
        getDramaById(id),
        getEpisodesByDramaId(id),
    ]);

    if (!drama) {
        notFound();
    }

    // Use drama poster as fallback for episode thumbnails
    const episodesWithThumbnails = episodes.map(ep => ({
        ...ep,
        thumbnailUrl: (ep.thumbnailUrl === '/placeholder-episode.jpg' || !ep.thumbnailUrl)
            ? (drama.posterUrl || '/placeholder-episode.jpg')
            : ep.thumbnailUrl
    }));

    return (
        <Suspense fallback={<EpisodeListSkeleton />}>
            <DramaDetailClient drama={drama} episodes={episodesWithThumbnails} />
        </Suspense>
    );
}
