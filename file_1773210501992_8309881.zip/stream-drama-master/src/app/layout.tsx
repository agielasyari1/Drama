import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import BottomNav from "@/components/layout/BottomNav";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: {
    default: "StreamDrama - Watch Korean Dramas Online",
    template: "%s | StreamDrama",
  },
  description: "Stream the latest Korean, Chinese, and Japanese dramas. Watch trending series, new releases, and classic favorites on StreamDrama.",
  keywords: ["drama", "kdrama", "streaming", "watch online", "korean drama", "asian drama"],
  authors: [{ name: "StreamDrama" }],
  creator: "StreamDrama",
  openGraph: {
    type: "website",
    locale: "en_US",
    siteName: "StreamDrama",
    title: "StreamDrama - Watch Korean Dramas Online",
    description: "Stream the latest Korean, Chinese, and Japanese dramas.",
  },
  twitter: {
    card: "summary_large_image",
    title: "StreamDrama",
    description: "Stream the latest drama series online",
  },
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "StreamDrama",
  },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#0a0a0a" },
  ],
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
        suppressHydrationWarning
      >
        <main className="min-h-screen">
          {children}
        </main>
        <BottomNav />
      </body>
    </html>
  );
}
