'use client';

import { useState } from 'react';
import Image from 'next/image';
import { User, Settings, Moon, Sun, Bell, HelpCircle, LogOut, ChevronRight } from 'lucide-react';
import Button from '@/components/ui/Button';
import { cn } from '@/lib/utils';

export default function ProfilePage() {
    const [isDarkMode, setIsDarkMode] = useState(true);
    const [notifications, setNotifications] = useState(true);

    // Mock user data
    const user = {
        name: 'Guest User',
        email: 'guest@streamdrama.com',
        avatar: null,
        memberSince: '2024',
    };

    const menuItems = [
        {
            icon: isDarkMode ? Moon : Sun,
            label: 'Dark Mode',
            action: () => setIsDarkMode(!isDarkMode),
            toggle: true,
            value: isDarkMode,
        },
        {
            icon: Bell,
            label: 'Notifications',
            action: () => setNotifications(!notifications),
            toggle: true,
            value: notifications,
        },
        { icon: Settings, label: 'Settings', href: '/settings' },
        { icon: HelpCircle, label: 'Help & Support', href: '/help' },
    ];

    return (
        <div className="min-h-screen p-4">
            {/* Profile Header */}
            <div className="flex items-center gap-4 mb-8">
                <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-primary/50 flex items-center justify-center">
                    {user.avatar ? (
                        <Image src={user.avatar} alt={user.name} width={80} height={80} className="w-full h-full rounded-full object-cover" />
                    ) : (
                        <User size={32} className="text-primary-foreground" />
                    )}
                </div>
                <div>
                    <h1 className="text-xl font-bold">{user.name}</h1>
                    <p className="text-sm text-muted-foreground">{user.email}</p>
                    <p className="text-xs text-muted-foreground mt-1">Member since {user.memberSince}</p>
                </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 mb-8">
                <div className="bg-card rounded-xl p-4 text-center">
                    <p className="text-2xl font-bold text-primary">12</p>
                    <p className="text-xs text-muted-foreground">Watching</p>
                </div>
                <div className="bg-card rounded-xl p-4 text-center">
                    <p className="text-2xl font-bold text-primary">45</p>
                    <p className="text-xs text-muted-foreground">Completed</p>
                </div>
                <div className="bg-card rounded-xl p-4 text-center">
                    <p className="text-2xl font-bold text-primary">8</p>
                    <p className="text-xs text-muted-foreground">My List</p>
                </div>
            </div>

            {/* Menu Items */}
            <div className="bg-card rounded-xl overflow-hidden divide-y divide-border">
                {menuItems.map((item, index) => (
                    <button
                        key={item.label}
                        onClick={item.action}
                        className="w-full flex items-center justify-between p-4 hover:bg-secondary/50 transition-colors"
                    >
                        <div className="flex items-center gap-3">
                            <item.icon size={20} className="text-muted-foreground" />
                            <span className="font-medium">{item.label}</span>
                        </div>
                        {item.toggle ? (
                            <div className={cn(
                                'w-11 h-6 rounded-full transition-colors relative',
                                item.value ? 'bg-primary' : 'bg-secondary'
                            )}>
                                <div className={cn(
                                    'absolute w-5 h-5 bg-white rounded-full top-0.5 transition-transform',
                                    item.value ? 'translate-x-5' : 'translate-x-0.5'
                                )} />
                            </div>
                        ) : (
                            <ChevronRight size={18} className="text-muted-foreground" />
                        )}
                    </button>
                ))}
            </div>

            {/* Sign Out */}
            <div className="mt-8">
                <Button variant="outline" className="w-full gap-2 text-red-500 border-red-500/30 hover:bg-red-500/10">
                    <LogOut size={18} />
                    Sign Out
                </Button>
            </div>

            {/* Version */}
            <p className="text-center text-xs text-muted-foreground mt-8">
                StreamDrama v1.0.0
            </p>
        </div>
    );
}
