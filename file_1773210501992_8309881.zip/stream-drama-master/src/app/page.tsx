'use client';

import { useHomeFeed } from '@/hooks/useDramas';
import HeroBanner from '@/components/drama/HeroBanner';
import Carousel from '@/components/ui/Carousel';
import { HeroBannerSkeleton, CarouselSkeleton } from '@/components/ui/Skeleton';

export default function HomePage() {
  const { data: sections, isLoading, error } = useHomeFeed();

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen p-4">
        <div className="text-center">
          <p className="text-muted-foreground">Something went wrong!</p>
          <p className="text-sm text-muted mt-1">Please try again later</p>
        </div>
      </div>
    );
  }

  // Get featured drama for hero
  const featuredDrama = sections?.find(s => s.type === 'trending')?.dramas[0];

  return (
    <div className="min-h-screen pb-4">
      {isLoading ? (
        <HeroBannerSkeleton />
      ) : featuredDrama ? (
        <HeroBanner drama={featuredDrama} />
      ) : null}

      <div className="space-y-8 mt-6">
        {isLoading ? (
          <>
            <CarouselSkeleton />
            <CarouselSkeleton />
            <CarouselSkeleton />
          </>
        ) : (
          sections?.map(section => (
            <Carousel
              key={section.id}
              title={section.title}
              dramas={section.dramas}
              showProgress={section.type === 'continue'}
            />
          ))
        )}
      </div>
    </div>
  );
}
