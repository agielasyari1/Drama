'use client';

import { useState } from 'react';
import useSWR from 'swr';
import { Bookmark, Trash2 } from 'lucide-react';
import { getMyList, removeFromMyList } from '@/lib/api';
import DramaCard from '@/components/ui/DramaCard';
import { CarouselSkeleton } from '@/components/ui/Skeleton';
import Button from '@/components/ui/Button';
import type { Drama } from '@/types';

export default function MyListPage() {
    const { data: dramas, isLoading, mutate } = useSWR<Drama[]>('my-list', getMyList);
    const [isEditing, setIsEditing] = useState(false);

    const handleRemove = async (id: string) => {
        await removeFromMyList(id);
        mutate();
    };

    return (
        <div className="min-h-screen p-4">
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
                <h1 className="text-2xl font-bold flex items-center gap-2">
                    <Bookmark size={24} />
                    My List
                </h1>
                {dramas && dramas.length > 0 && (
                    <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setIsEditing(!isEditing)}
                    >
                        {isEditing ? 'Done' : 'Edit'}
                    </Button>
                )}
            </div>

            {/* Content */}
            {isLoading ? (
                <CarouselSkeleton />
            ) : dramas && dramas.length > 0 ? (
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-3">
                    {dramas.map(drama => (
                        <div key={drama.id} className="relative">
                            <DramaCard drama={drama} size="md" />
                            {isEditing && (
                                <button
                                    onClick={() => handleRemove(drama.id)}
                                    className="absolute top-1 right-1 p-1.5 bg-red-500 rounded-full text-white shadow-lg z-10"
                                    aria-label="Remove from list"
                                >
                                    <Trash2 size={14} />
                                </button>
                            )}
                        </div>
                    ))}
                </div>
            ) : (
                <div className="flex flex-col items-center justify-center py-20 text-center">
                    <Bookmark size={48} className="text-muted-foreground mb-4" />
                    <h2 className="text-lg font-semibold mb-2">Your list is empty</h2>
                    <p className="text-muted-foreground text-sm max-w-xs">
                        Add dramas to your list by tapping the + button on any drama page
                    </p>
                </div>
            )}
        </div>
    );
}
