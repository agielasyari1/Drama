// DramaBox API types based on the API documentation

// Drama/Book item from API
export interface ApiDrama {
  id: string;
  bookId?: string;
  title?: string;
  bookName?: string; // Actual field name from DramaBox API
  cover: string;
  coverWap?: string;
  coverLandscape?: string;
  description?: string;
  synopsis?: string;
  introduction?: string; // Actual field name from DramaBox API
  rating?: number;
  score?: number;
  totalChapters?: number;
  chapters?: number;
  chapterCount?: number; // Actual field name from DramaBox API
  playCount?: string; // e.g. "107K"
  genre?: string[];
  genres?: string[];
  tags?: string[];
  status?: string;
  updateStatus?: string;
  country?: string;
  year?: number;
  releaseYear?: number;
  cast?: ApiCastMember[];
  source?: string;
  lang?: string;
  corner?: { cornerType: number; name: string; color: string };
  rank?: { rankType: number; hotCode: string; recCopy: string; sort: number } | null;
}

export interface ApiCastMember {
  id?: string;
  name: string;
  role?: string;
  character?: string;
  avatar?: string;
  image?: string;
}

export interface ApiEpisode {
  id?: string;
  chapterId?: string;
  chapterIndex: number;
  chapterName?: string;
  title?: string;
  duration?: number;
  chapterImg?: string;
  thumbnail?: string;
  cover?: string;
  isFree?: boolean;
  isLocked?: boolean;
  isCharge?: boolean | number;
  isPay?: boolean;
  chargeChapter?: boolean;
  cdnList?: any[];
}

export interface ApiChapterDetail {
  bookId: string;
  chapterIndex: number;
  title: string;
  duration?: number;
  thumbnail?: string;
  videoUrl?: string;
  subtitles?: ApiSubtitle[];
}

export interface ApiSubtitle {
  language: string;
  url: string;
}

export interface ApiVideoStream {
  bookId: string;
  chapterIndex: number;
  videoUrl: string;
  qualities: ApiVideoQuality[];
  cover: string;
  unlockedNow?: boolean;
  originalStatus?: { isCharge: number };
}

export interface ApiVideoQuality {
  quality: number;
  videoPath: string;
  isDefault: number;
  isEntry: number;
  isVipEquity: number;
}

export interface ApiSearchResult {
  list: ApiDrama[];
  total?: number;
  page?: number;
  pageSize?: number;
  hasMore?: boolean;
}

export interface ApiForYouResponse {
  banners?: ApiDrama[];
  sections?: ApiSection[];
  list?: ApiDrama[];
}

export interface ApiSection {
  id: string;
  title: string;
  type: string;
  list: ApiDrama[];
}

export interface ApiGenre {
  id: string;
  name: string;
  code?: string;
}

// Transformed types for the app (keeping existing structure)
export interface Drama {
  id: string;
  title: string;
  originalTitle?: string;
  posterUrl: string;
  backdropUrl: string;
  synopsis: string;
  rating: number;
  year: number;
  genre: string[];
  country: string;
  episodes: number;
  status: 'ongoing' | 'completed';
  cast: CastMember[];
}

export interface CastMember {
  id: string;
  name: string;
  role: string;
  imageUrl: string;
}

export interface Episode {
  id: string;
  dramaId: string;
  number: number;
  title: string;
  duration: number;
  thumbnailUrl: string;
  videoUrl: string;
  synopsis?: string;
  airDate: string;
  isLocked?: boolean;
}

export interface WatchProgress {
  episodeId: string;
  dramaId: string;
  progress: number;
  lastWatched: string;
}

export interface UserProfile {
  id: string;
  name: string;
  avatarUrl: string;
  myList: string[];
  watchHistory: WatchProgress[];
}

export interface SearchResult {
  dramas: Drama[];
  total: number;
}

export interface CarouselSection {
  id: string;
  title: string;
  type: 'trending' | 'new' | 'genre' | 'continue' | 'mylist' | 'foryou' | 'rank';
  dramas: Drama[];
}
