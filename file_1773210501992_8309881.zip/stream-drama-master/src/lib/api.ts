// DramaBox API service layer
// Proxied through /api/drama/[...path] for authentication

import type {
    Drama,
    Episode,
    CarouselSection,
    SearchResult,
    WatchProgress,
    ApiDrama,
    ApiEpisode,
    ApiForYouResponse,
    ApiSearchResult,
    ApiChapterDetail,
    ApiVideoStream
} from '@/types';

// API Configuration - use local proxy which adds auth header server-side
const API_LANG = 'in'; // Indonesian

// Get base URL for API calls
// On server: need absolute URL with host
// On client: can use relative URL
function getApiBaseUrl(): string {
    if (typeof window !== 'undefined') {
        // Client-side: use relative URL
        return '/api/drama';
    }
    // Server-side: use absolute URL
    // Check for various deployment and dev environment variables
    if (process.env.VERCEL_URL) {
        return `https://${process.env.VERCEL_URL}/api/drama`;
    }
    if (process.env.NEXT_PUBLIC_APP_URL) {
        return `${process.env.NEXT_PUBLIC_APP_URL}/api/drama`;
    }
    // Development: use PORT env var or detect from Next.js config
    const port = process.env.PORT || '3001';
    return `http://localhost:${port}/api/drama`;
}

// Helper function for API calls through local proxy
// External API Base URL (same as in route.ts)
const API_BASE_EXTERNAL = 'https://api.sansekai.my.id/api';

// Simple in-memory cache to prevent rate-limiting (429 Too Many Requests)
const MEMORY_CACHE = new Map<string, { data: any, timestamp: number }>();
const CACHE_DURATION_MS = 60000; // 1 minute

// Helper function for API calls
async function apiCall<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const isGet = !options.method || options.method === 'GET';
    const cacheKey = endpoint;

    // Check cache for GET requests
    if (isGet && MEMORY_CACHE.has(cacheKey)) {
        const cached = MEMORY_CACHE.get(cacheKey)!;
        if (Date.now() - cached.timestamp < CACHE_DURATION_MS) {
            return cached.data;
        }
    }

    // Server-side: Call external API directly to avoid loopback/port issues
    if (typeof window === 'undefined') {
        const url = `${API_BASE_EXTERNAL}${endpoint}`;
        const token = process.env.NEXT_PUBLIC_DRAMABOX_TOKEN || '';

        const response = await fetch(url, {
            ...options,
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                ...(token && { 'Authorization': `Bearer ${token}` }),
                ...options.headers,
            },
        });

        if (!response.ok) {
            throw new Error(`API Error: ${response.status} ${response.statusText}`);
        }

        const data = await response.json();
        if (isGet) {
            MEMORY_CACHE.set(cacheKey, { data, timestamp: Date.now() });
        }
        return data;
    }

    // Client-side: Route through our Next.js API proxy
    const baseUrl = '/api/drama';
    const url = `${baseUrl}${endpoint}`;

    const response = await fetch(url, {
        ...options,
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            ...options.headers,
        },
    });

    if (!response.ok) {
        throw new Error(`API Error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    if (isGet) {
        MEMORY_CACHE.set(cacheKey, { data, timestamp: Date.now() });
    }
    return data;
}

// Transform API drama to app Drama type
// API returns: bookId, bookName, introduction, cover, chapterCount, tags, etc.
function transformDrama(apiDrama: ApiDrama): Drama {
    return {
        id: apiDrama.bookId || apiDrama.id,
        title: apiDrama.bookName || apiDrama.title || 'Unknown Title',
        originalTitle: undefined,
        posterUrl: apiDrama.coverWap || apiDrama.cover || '/placeholder-poster.jpg',
        backdropUrl: apiDrama.coverLandscape || apiDrama.coverWap || apiDrama.cover || '/placeholder-backdrop.jpg',
        synopsis: apiDrama.introduction || apiDrama.description || apiDrama.synopsis || 'No description available.',
        rating: apiDrama.rating || apiDrama.score || 8.5,
        year: apiDrama.year || apiDrama.releaseYear || new Date().getFullYear(),
        genre: apiDrama.tags || apiDrama.genre || apiDrama.genres || ['Drama'],
        country: apiDrama.country || 'Indonesia',
        episodes: apiDrama.chapterCount || apiDrama.totalChapters || apiDrama.chapters || 0,
        status: (apiDrama.status === 'completed' || apiDrama.updateStatus === 'END') ? 'completed' : 'ongoing',
        cast: (apiDrama.cast || []).map((c, i) => ({
            id: c.id || `cast-${i}`,
            name: c.name,
            role: c.role || c.character || 'Unknown',
            imageUrl: c.avatar || c.image || '/placeholder-avatar.jpg',
        })),
    };
}

// Transform API episode to app Episode type
// API returns: chapterId, chapterIndex, isCharge, isPay, chapterSizeVoList
function transformEpisode(apiEp: ApiEpisode, dramaId: string): Episode {
    const episodeNumber = (apiEp.chapterIndex ?? 0) + 1; // API uses 0-based index

    // Extract video URL if available in cdnList
    let videoUrl = '';
    if (apiEp.cdnList && apiEp.cdnList.length > 0) {
        // Find a CDN that has video paths and try to find one without signature expiry if possible
        let bestCdn = apiEp.cdnList.find((cdn: any) => cdn.isDefault === 1);
        if (!bestCdn || !bestCdn.videoPathList || bestCdn.videoPathList.length === 0) {
            bestCdn = apiEp.cdnList.find((cdn: any) => cdn.videoPathList && cdn.videoPathList.length > 0) || apiEp.cdnList[0];
        }

        if (bestCdn && bestCdn.videoPathList && bestCdn.videoPathList.length > 0) {
            // First try to find a default one, otherwise the highest quality one
            let videoPathObj = bestCdn.videoPathList.find((v: any) => v.isDefault === 1) || bestCdn.videoPathList[0];

            // However, prefer a CDN/videoPath that does NOT contain "Signature=" to avoid expiry issues if possible
            const cdnWithoutSignature = apiEp.cdnList.find((cdn: any) =>
                cdn.videoPathList?.some((v: any) => !v.videoPath?.includes('Signature='))
            );

            if (cdnWithoutSignature && cdnWithoutSignature.videoPathList) {
                const pathObj = cdnWithoutSignature.videoPathList.find((v: any) => !v.videoPath?.includes('Signature=') && v.isDefault === 1)
                    || cdnWithoutSignature.videoPathList.find((v: any) => !v.videoPath?.includes('Signature='))

                if (pathObj) {
                    videoPathObj = pathObj;
                }
            }

            videoUrl = videoPathObj?.videoPath || '';
        }
    }

    const isLocked = apiEp.chargeChapter === true ||
        apiEp.isCharge === 1 ||
        apiEp.isCharge === true ||
        apiEp.isPay === true ||
        apiEp.isLocked === true;

    return {
        id: `${dramaId}-ep${apiEp.chapterIndex ?? 0}`,
        dramaId,
        number: episodeNumber,
        title: apiEp.chapterName || apiEp.title || `Episode ${episodeNumber}`,
        duration: apiEp.duration || 45,
        thumbnailUrl: apiEp.chapterImg || apiEp.thumbnail || apiEp.cover || '/placeholder-episode.jpg',
        videoUrl: videoUrl, // Populated directly if available
        synopsis: '',
        airDate: new Date().toISOString(),
        isLocked,
    };
}

// ============ API ENDPOINTS ============

// Response wrapper type for legacy API (not used much anymore)
interface ApiResponse<T> {
    success: boolean;
    data: T;
    meta?: { source?: string };
}

// GET /dramabox/foryou - Recommendations (Home feed)
export async function getForYou(page: number = 1): Promise<ApiForYouResponse> {
    const response = await apiCall<ApiDrama[]>(`/dramabox/foryou?page=${page}&lang=${API_LANG}`);
    return { list: response || [] };
}

// GET /dramabox/latest - New releases
export async function getNewReleases(page: number = 1, pageSize: number = 10): Promise<Drama[]> {
    const response = await apiCall<ApiDrama[]>(`/dramabox/latest?page=${page}&lang=${API_LANG}&pageSize=${pageSize}`);
    return (response || []).map(transformDrama);
}

// GET /dramabox/trending - Popular ranking
export async function getTrendingDramas(page: number = 1): Promise<Drama[]> {
    const response = await apiCall<ApiDrama[]>(`/dramabox/trending?page=${page}&lang=${API_LANG}`);
    return (response || []).map(transformDrama);
}

// GET /dramabox/classify - Filter by genre
export async function getDramasByGenre(genre: string, page: number = 1, sort: number = 1): Promise<Drama[]> {
    const response = await apiCall<ApiDrama[]>(
        `/dramabox/classify?lang=${API_LANG}&pageNo=${page}&genre=${genre}&sort=${sort}`
    );
    return (response || []).map(transformDrama);
}

// GET /dramabox/search - Search dramas
export async function searchDramas(query: string, page: number = 1): Promise<SearchResult> {
    if (!query.trim()) {
        return { dramas: [], total: 0 };
    }

    const list = await apiCall<ApiDrama[]>(`/dramabox/search?query=${encodeURIComponent(query)}&page=${page}&lang=${API_LANG}`);
    return {
        dramas: (list || []).map(transformDrama),
        total: list?.length || 0,
    };
}

// GET /dramabox/populersearch for Search suggestions
export async function getSearchSuggestions(query: string): Promise<string[]> {
    if (!query.trim()) {
        return [];
    }

    try {
        const data = await apiCall<ApiDrama[]>(`/dramabox/search?query=${encodeURIComponent(query)}&page=1&lang=${API_LANG}`);
        // Extract titles for suggestions
        return (data || []).slice(0, 5).map(d => d.bookName || d.title || '');
    } catch (error) {
        console.error('Error fetching suggestions:', error);
        return [];
    }
}

// GET /dramabox/dubindo - Sub Indo (Indonesian dubbed/subbed dramas)
export async function getSubIndo(page: number = 1, classify: string = 'terpopuler'): Promise<Drama[]> {
    const response = await apiCall<ApiDrama[]>(`/dramabox/dubindo?classify=${classify}&page=${page}&lang=${API_LANG}`);
    return (response || []).map(transformDrama);
}

// GET /dramabox/allepisode - Episode list
export async function getEpisodesByDramaId(dramaId: string): Promise<Episode[]> {
    try {
        const response = await apiCall<ApiEpisode[]>(`/dramabox/allepisode?bookId=${dramaId}&lang=${API_LANG}`);
        return (response || []).map(ep => transformEpisode(ep, dramaId));
    } catch (error) {
        console.error('Error fetching episodes:', error);
        return [];
    }
}

// GET /dramabox/detail - Episode details
export async function getEpisodeDetails(dramaId: string): Promise<ApiChapterDetail[]> {
    try {
        const response = await apiCall<ApiChapterDetail | ApiChapterDetail[]>(`/dramabox/detail?bookId=${dramaId}&lang=${API_LANG}`);
        return Array.isArray(response) ? response : [response];
    } catch (error) {
        console.error('Error fetching episode details:', error);
        return [];
    }
}

// GET /dramabox/watch - Video stream URL (assuming this exists or falling back to older if it fails)
export async function getVideoStream(dramaId: string, episodeIndex: number): Promise<ApiVideoStream | null> {
    try {
        const response = await apiCall<ApiVideoStream>(`/dramabox/watch?id=${dramaId}&episode=${episodeIndex}&lang=${API_LANG}&source=search_result`);
        return response;
    } catch (error) {
        console.error('Error fetching video stream:', error);
        // Sometimes endpoints are not correctly mapped, let's keep a fallback to null
        return null;
    }
}

// POST /dramabox/watch/player - Alternative video stream
export async function getVideoStreamPost(dramaId: string, chapterIndex: number): Promise<ApiVideoStream> {
    return apiCall<ApiVideoStream>('/dramabox/watch/player?lang=' + API_LANG, {
        method: 'POST',
        body: JSON.stringify({
            bookId: dramaId,
            chapterIndex,
            lang: API_LANG,
        }),
    });
}

// Get drama by ID
export async function getDramaById(id: string): Promise<Drama | null> {
    try {
        const response = await apiCall<ApiDrama | ApiDrama[]>(`/dramabox/detail?bookId=${id}&lang=${API_LANG}`);
        const data = Array.isArray(response) ? response[0] : response;

        if (data && (data.bookId || data.id)) {
            return transformDrama(data);
        }

        // Fallback: search for the drama
        const searchResult = await searchDramas(id);
        return searchResult.dramas.find(d => d.id === id) || null;
    } catch (error) {
        console.error('Error fetching drama:', error);
        return null;
    }
}

// Get episode by ID
// Get episode by ID
export async function getEpisodeById(episodeId: string, fetchStream: boolean = true): Promise<Episode | null> {
    try {
        // Parse episode ID format: {dramaId}-ep{index}
        const match = episodeId.match(/^(.+)-ep(\d+)$/);
        if (!match) return null;

        const [, dramaId, epIndexStr] = match;
        const epIndex = parseInt(epIndexStr, 10);

        const episodes = await getEpisodesByDramaId(dramaId);
        const episode = episodes.find(e => e.id === episodeId);

        if (episode && fetchStream) {
            // Get video stream URL
            // If we don't already have the videoUrl from allepisodes (which the new API provides)
            if (!episode.videoUrl || episode.videoUrl === '') {
                // Parse actual chapter index from ID
                const chapterIndex = parseInt(epIndexStr, 10);
                const stream = await getVideoStream(dramaId, chapterIndex);
                if (stream && stream.videoUrl) {
                    episode.videoUrl = stream.videoUrl;
                }
            }
        }

        return episode || null;
    } catch (error) {
        console.error('Error fetching episode:', error);
        return null;
    }
}

// Get home feed with all sections
export async function getHomeFeed(): Promise<CarouselSection[]> {
    try {
        const [forYouData, newReleases, trending, subIndo] = await Promise.all([
            getForYou(1).catch(() => ({ sections: [], list: [] })),
            getNewReleases(1).catch(() => []),
            getTrendingDramas(1).catch(() => []),
            getSubIndo(1).catch(() => []),
        ]);

        const sections: CarouselSection[] = [];

        // Add trending section
        if (trending.length > 0) {
            sections.push({
                id: 'trending',
                title: 'Trending Now',
                type: 'rank',
                dramas: trending,
            });
        }

        // Add new releases
        if (newReleases.length > 0) {
            sections.push({
                id: 'new',
                title: 'New Releases',
                type: 'new',
                dramas: newReleases,
            });
        }

        // Add Sub Indo section
        if (subIndo.length > 0) {
            sections.push({
                id: 'sub-indo',
                title: 'Sub Indo',
                type: 'foryou',
                dramas: subIndo,
            });
        }

        // Add for you sections if available
        if (forYouData.sections) {
            forYouData.sections.forEach((section, i) => {
                sections.push({
                    id: `foryou-${i}`,
                    title: section.title,
                    type: 'foryou',
                    dramas: section.list.map(transformDrama),
                });
            });
        } else if (forYouData.list && forYouData.list.length > 0) {
            sections.push({
                id: 'foryou',
                title: 'For You',
                type: 'foryou',
                dramas: forYouData.list.map(transformDrama),
            });
        }

        // Add continue watching from localStorage
        const continueWatching = getContinueWatching();
        if (continueWatching.length > 0) {
            sections.unshift({
                id: 'continue',
                title: 'Continue Watching',
                type: 'continue',
                dramas: continueWatching,
            });
        }

        return sections;
    } catch (error) {
        console.error('Error fetching home feed:', error);
        return [];
    }
}

// ============ LOCAL STORAGE HELPERS ============

// Watch progress (stored locally)
export function getWatchProgress(): WatchProgress[] {
    if (typeof window === 'undefined') return [];
    const stored = localStorage.getItem('watchProgress');
    return stored ? JSON.parse(stored) : [];
}

export function updateWatchProgress(progress: WatchProgress, drama?: Drama | null): boolean {
    if (typeof window === 'undefined') return false;
    const allProgress = getWatchProgress();
    const index = allProgress.findIndex(p => p.episodeId === progress.episodeId);
    if (index > -1) {
        allProgress[index] = progress;
    } else {
        allProgress.push(progress);
    }
    localStorage.setItem('watchProgress', JSON.stringify(allProgress));

    // Cache drama details for continue watching
    if (drama) {
        saveDramaToCache(drama);
    }

    return true;
}

// Drama Cache helpers
function getDramaCache(): Record<string, Drama> {
    if (typeof window === 'undefined') return {};
    const stored = localStorage.getItem('dramaCache');
    return stored ? JSON.parse(stored) : {};
}

function saveDramaToCache(drama: Drama) {
    if (typeof window === 'undefined') return;
    const cache = getDramaCache();
    cache[drama.id] = drama;
    localStorage.setItem('dramaCache', JSON.stringify(cache));
}

// Continue watching dramas (derived from watch progress)
function getContinueWatching(): Drama[] {
    if (typeof window === 'undefined') return [];
    const progress = getWatchProgress();
    const cache = getDramaCache();

    // Sort by lastWatched desc
    progress.sort((a, b) => new Date(b.lastWatched).getTime() - new Date(a.lastWatched).getTime());

    // Map to dramas, filter nulls and duplicates
    const dramas: Drama[] = [];
    const seenIds = new Set<string>();

    for (const p of progress) {
        if (seenIds.has(p.dramaId)) continue;
        const d = cache[p.dramaId];
        if (d) {
            dramas.push(d);
            seenIds.add(p.dramaId);
        }
    }

    return dramas;
}

// My List (stored locally)
export function getMyList(): Drama[] {
    if (typeof window === 'undefined') return [];
    const stored = localStorage.getItem('myList');
    return stored ? JSON.parse(stored) : [];
}

export function addToMyList(drama: Drama): boolean {
    if (typeof window === 'undefined') return false;
    const list = getMyList();
    if (!list.find(d => d.id === drama.id)) {
        list.push(drama);
        localStorage.setItem('myList', JSON.stringify(list));
    }
    return true;
}

export function removeFromMyList(dramaId: string): boolean {
    if (typeof window === 'undefined') return false;
    const list = getMyList();
    const filtered = list.filter(d => d.id !== dramaId);
    localStorage.setItem('myList', JSON.stringify(filtered));
    return true;
}

export function isInMyList(dramaId: string): boolean {
    const list = getMyList();
    return list.some(d => d.id === dramaId);
}
