'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import {
    Play,
    Pause,
    SkipBack,
    SkipForward,
    Volume2,
    VolumeX,
    Maximize,
    Minimize,
    Settings,
    ChevronLeft,
    List,
    StepBack,
    StepForward
} from 'lucide-react';
import { cn, formatDuration } from '@/lib/utils';

interface VideoPlayerProps {
    videoUrl: string;
    title: string;
    episodeNumber: number;
    dramaTitle: string;
    onProgress?: (progress: number) => void;
    initialProgress?: number;
    onNextEpisode?: () => void;
    hasNextEpisode?: boolean;
    onBack?: () => void;
    onPrevEpisode?: () => void;
    hasPrevEpisode?: boolean;
}

export default function VideoPlayer({
    videoUrl,
    title,
    episodeNumber,
    dramaTitle,
    onProgress,
    initialProgress = 0,
    onNextEpisode,
    hasNextEpisode = false,
    onBack,
    onPrevEpisode,
    hasPrevEpisode = false,
}: VideoPlayerProps) {
    const router = useRouter();
    const videoRef = useRef<HTMLVideoElement>(null);
    const containerRef = useRef<HTMLDivElement>(null);
    const controlsTimeoutRef = useRef<NodeJS.Timeout | undefined>(undefined);

    const [isPlaying, setIsPlaying] = useState(false);
    const [isMuted, setIsMuted] = useState(false);
    const [isFullscreen, setIsFullscreen] = useState(false);
    const [showControls, setShowControls] = useState(true);
    const [currentTime, setCurrentTime] = useState(0);
    const [duration, setDuration] = useState(0);
    const [progress, setProgress] = useState(0);
    const [showQuality, setShowQuality] = useState(false);
    const [quality, setQuality] = useState<'auto' | '720p' | '480p' | '360p'>('auto');
    const [showNextCountdown, setShowNextCountdown] = useState(false);
    const [nextCountdown, setNextCountdown] = useState(5);

    // Format time in mm:ss or hh:mm:ss
    const formatTime = (seconds: number) => {
        const hrs = Math.floor(seconds / 3600);
        const mins = Math.floor((seconds % 3600) / 60);
        const secs = Math.floor(seconds % 60);

        if (hrs > 0) {
            return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        }
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    };

    // Toggle play/pause
    const togglePlay = useCallback(() => {
        if (!videoRef.current) return;

        if (isPlaying) {
            videoRef.current.pause();
        } else {
            videoRef.current.play();
        }
        setIsPlaying(!isPlaying);
        showControlsTemporarily();
    }, [isPlaying]);

    // Skip forward/backward
    const skip = useCallback((seconds: number) => {
        if (!videoRef.current) return;
        videoRef.current.currentTime = Math.max(0, Math.min(duration, videoRef.current.currentTime + seconds));
        showControlsTemporarily();
    }, [duration]);

    // Toggle mute
    const toggleMute = useCallback(() => {
        if (!videoRef.current) return;
        videoRef.current.muted = !isMuted;
        setIsMuted(!isMuted);
    }, [isMuted]);

    // Toggle fullscreen
    const toggleFullscreen = useCallback(async () => {
        const container = containerRef.current;
        const video = videoRef.current;

        if (!container || !video) return;

        try {
            // Check for fullscreen element (standard and vendor prefixed)
            const isFullscreenActive = document.fullscreenElement ||
                (document as any).webkitFullscreenElement ||
                (document as any).mozFullScreenElement ||
                (document as any).msFullscreenElement;

            if (isFullscreenActive) {
                if (document.exitFullscreen) {
                    await document.exitFullscreen();
                } else if ((document as any).webkitExitFullscreen) {
                    await (document as any).webkitExitFullscreen();
                } else if ((document as any).mozCancelFullScreen) {
                    await (document as any).mozCancelFullScreen();
                } else if ((document as any).msExitFullscreen) {
                    await (document as any).msExitFullscreen();
                }
                setIsFullscreen(false);
            } else {
                // Try container fullscreen first
                if (container.requestFullscreen) {
                    await container.requestFullscreen();
                    setIsFullscreen(true);
                } else if ((container as any).webkitRequestFullscreen) {
                    await (container as any).webkitRequestFullscreen();
                    setIsFullscreen(true);
                } else if ((container as any).mozRequestFullScreen) {
                    await (container as any).mozRequestFullScreen();
                    setIsFullscreen(true);
                } else if ((container as any).msRequestFullscreen) {
                    await (container as any).msRequestFullscreen();
                    setIsFullscreen(true);
                } else if ((video as any).webkitEnterFullscreen) {
                    // iOS Fallback: specific to <video> element
                    (video as any).webkitEnterFullscreen();
                    setIsFullscreen(true);
                }
            }
        } catch (err) {
            console.error('Fullscreen error:', err);
        }
    }, []);

    // Show controls temporarily
    const showControlsTemporarily = useCallback(() => {
        setShowControls(true);
        if (controlsTimeoutRef.current) {
            clearTimeout(controlsTimeoutRef.current);
        }
        if (isPlaying) {
            controlsTimeoutRef.current = setTimeout(() => {
                setShowControls(false);
            }, 3000);
        }
    }, [isPlaying]);

    // Handle seek
    const handleSeek = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
        if (!videoRef.current) return;
        const rect = e.currentTarget.getBoundingClientRect();
        const percent = (e.clientX - rect.left) / rect.width;
        videoRef.current.currentTime = percent * duration;
        showControlsTemporarily();
    }, [duration, showControlsTemporarily]);

    // Update time
    const handleTimeUpdate = useCallback(() => {
        if (!videoRef.current) return;
        const current = videoRef.current.currentTime;
        const dur = videoRef.current.duration;

        setCurrentTime(current);
        setDuration(dur);

        const prog = (current / dur) * 100;
        setProgress(prog);
        onProgress?.(prog);

        // Show next episode countdown when 10 seconds from end
        if (hasNextEpisode && dur - current <= 10 && !showNextCountdown) {
            setShowNextCountdown(true);
            setNextCountdown(Math.ceil(dur - current));
        }
    }, [onProgress, hasNextEpisode, showNextCountdown]);

    // Handle video end
    const handleEnded = useCallback(() => {
        setIsPlaying(false);
        if (hasNextEpisode && onNextEpisode) {
            onNextEpisode();
        }
    }, [hasNextEpisode, onNextEpisode]);

    // Next countdown timer
    useEffect(() => {
        if (showNextCountdown && nextCountdown > 0) {
            const timer = setTimeout(() => {
                setNextCountdown(prev => prev - 1);
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [showNextCountdown, nextCountdown]);

    // Keyboard shortcuts
    useEffect(() => {
        const handleKeydown = (e: KeyboardEvent) => {
            switch (e.key) {
                case ' ':
                case 'k':
                    e.preventDefault();
                    togglePlay();
                    break;
                case 'ArrowLeft':
                    skip(-10);
                    break;
                case 'ArrowRight':
                    skip(10);
                    break;
                case 'm':
                    toggleMute();
                    break;
                case 'f':
                    toggleFullscreen();
                    break;
            }
        };

        window.addEventListener('keydown', handleKeydown);
        return () => window.removeEventListener('keydown', handleKeydown);
    }, [togglePlay, skip, toggleMute, toggleFullscreen]);

    // Cleanup
    useEffect(() => {
        return () => {
            if (controlsTimeoutRef.current) {
                clearTimeout(controlsTimeoutRef.current);
            }
        };
    }, []);

    return (
        <div
            ref={containerRef}
            className="relative w-full h-full bg-black"
            onClick={showControlsTemporarily}
            onMouseMove={showControlsTemporarily}
        >
            {/* Video Element */}
            <video
                ref={videoRef}
                src={videoUrl}
                className="w-full h-full object-contain"
                onTimeUpdate={handleTimeUpdate}
                onLoadedMetadata={() => setDuration(videoRef.current?.duration || 0)}
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
                onEnded={handleEnded}
                playsInline
            />

            {/* Controls Overlay */}
            <div className={cn(
                'absolute inset-0 transition-opacity duration-300',
                showControls ? 'opacity-100' : 'opacity-0 pointer-events-none'
            )}>
                {/* Gradient overlays */}
                <div className="absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-black/80 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 h-32 bg-gradient-to-t from-black/80 to-transparent" />

                {/* Top Bar */}
                <div className="absolute top-0 left-0 right-0 p-4 flex items-center gap-4">
                    <button
                        onClick={(e) => {
                            e.stopPropagation();
                            if (onBack) {
                                onBack();
                            } else {
                                router.back();
                            }
                        }}
                        className="p-2 rounded-full bg-black/50 hover:bg-black/70 transition-colors z-10"
                        aria-label="Go back"
                    >
                        <ChevronLeft size={24} className="text-white" />
                    </button>
                    <div className="flex-1">
                        <p className="text-white font-semibold line-clamp-1">{dramaTitle}</p>
                        <p className="text-white/70 text-sm">Episode {episodeNumber}: {title}</p>
                    </div>
                    <button className="p-2 rounded-full bg-black/50 hover:bg-black/70 transition-colors">
                        <List size={20} className="text-white" />
                    </button>
                </div>

                {/* Center Controls */}
                <div className="absolute inset-0 flex items-center justify-center gap-6">
                    {/* Previous Episode */}
                    <button
                        onClick={(e) => {
                            e.stopPropagation();
                            if (onPrevEpisode) onPrevEpisode();
                        }}
                        disabled={!hasPrevEpisode}
                        className={cn(
                            "p-2 rounded-full bg-black/50 hover:bg-black/70 transition-colors",
                            !hasPrevEpisode && "opacity-50 cursor-not-allowed hidden sm:block"
                        )}
                        aria-label="Previous Episode"
                    >
                        <StepBack size={24} className="text-white" />
                    </button>

                    {/* Skip Back */}
                    <button
                        onClick={(e) => { e.stopPropagation(); skip(-10); }}
                        className="p-3 rounded-full bg-black/50 hover:bg-black/70 transition-colors"
                        aria-label="Skip back 10 seconds"
                    >
                        <SkipBack size={28} className="text-white" />
                    </button>

                    {/* Play/Pause */}
                    <button
                        onClick={(e) => { e.stopPropagation(); togglePlay(); }}
                        className="p-5 rounded-full bg-primary hover:bg-primary/90 transition-colors shadow-lg scale-110"
                        aria-label={isPlaying ? 'Pause' : 'Play'}
                    >
                        {isPlaying ? (
                            <Pause size={36} className="text-white fill-white" />
                        ) : (
                            <Play size={36} className="text-white fill-white ml-1" />
                        )}
                    </button>

                    {/* Skip Forward */}
                    <button
                        onClick={(e) => { e.stopPropagation(); skip(10); }}
                        className="p-3 rounded-full bg-black/50 hover:bg-black/70 transition-colors"
                        aria-label="Skip forward 10 seconds"
                    >
                        <SkipForward size={28} className="text-white" />
                    </button>

                    {/* Next Episode */}
                    <button
                        onClick={(e) => {
                            e.stopPropagation();
                            if (onNextEpisode) onNextEpisode();
                        }}
                        disabled={!hasNextEpisode}
                        className={cn(
                            "p-2 rounded-full bg-black/50 hover:bg-black/70 transition-colors",
                            !hasNextEpisode && "opacity-50 cursor-not-allowed hidden sm:block"
                        )}
                        aria-label="Next Episode"
                    >
                        <StepForward size={24} className="text-white" />
                    </button>
                </div>

                {/* Bottom Controls */}
                <div className="absolute bottom-0 left-0 right-0 p-4 space-y-3">
                    {/* Progress Bar */}
                    <div
                        className="w-full h-1.5 bg-white/30 rounded-full cursor-pointer group"
                        onClick={handleSeek}
                    >
                        <div
                            className="h-full bg-primary rounded-full relative transition-all"
                            style={{ width: `${progress}%` }}
                        >
                            <div className="absolute right-0 top-1/2 -translate-y-1/2 w-4 h-4 bg-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow" />
                        </div>
                    </div>

                    {/* Time & Controls */}
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                            <span className="text-white text-sm font-mono">
                                {formatTime(currentTime)} / {formatTime(duration)}
                            </span>
                            <button
                                onClick={toggleMute}
                                className="p-1 text-white hover:text-primary transition-colors"
                                aria-label={isMuted ? 'Unmute' : 'Mute'}
                            >
                                {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
                            </button>
                        </div>

                        <div className="flex items-center gap-3">
                            {/* Quality Selector */}
                            <div className="relative">
                                <button
                                    onClick={() => setShowQuality(!showQuality)}
                                    className="p-1 text-white hover:text-primary transition-colors flex items-center gap-1 text-sm"
                                >
                                    <Settings size={18} />
                                    <span>{quality}</span>
                                </button>
                                {showQuality && (
                                    <div className="absolute bottom-full right-0 mb-2 bg-black/90 rounded-lg overflow-hidden">
                                        {(['auto', '720p', '480p', '360p'] as const).map(q => (
                                            <button
                                                key={q}
                                                onClick={() => { setQuality(q); setShowQuality(false); }}
                                                className={cn(
                                                    'block w-full px-4 py-2 text-sm text-left hover:bg-white/10',
                                                    quality === q ? 'text-primary' : 'text-white'
                                                )}
                                            >
                                                {q}
                                            </button>
                                        ))}
                                    </div>
                                )}
                            </div>

                            {/* Fullscreen */}
                            <button
                                onClick={toggleFullscreen}
                                className="p-1 text-white hover:text-primary transition-colors"
                                aria-label={isFullscreen ? 'Exit fullscreen' : 'Fullscreen'}
                            >
                                {isFullscreen ? <Minimize size={20} /> : <Maximize size={20} />}
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {/* Next Episode Countdown */}
            {showNextCountdown && hasNextEpisode && (
                <div className="absolute bottom-20 right-4 bg-black/80 rounded-lg p-4 animate-slideUp">
                    <p className="text-white text-sm mb-2">Next episode in {nextCountdown}s</p>
                    <div className="flex gap-2">
                        <button
                            onClick={() => setShowNextCountdown(false)}
                            className="px-3 py-1.5 text-sm text-white/70 hover:text-white transition-colors"
                        >
                            Cancel
                        </button>
                        <button
                            onClick={onNextEpisode}
                            className="px-3 py-1.5 bg-primary text-white text-sm rounded font-medium hover:bg-primary/90 transition-colors"
                        >
                            Play Now
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
}
