'use client';

import Link from 'next/link';
import Image from 'next/image';
import { Play, CheckCircle } from 'lucide-react';
import type { Episode } from '@/types';
import { formatDuration, cn } from '@/lib/utils';

interface EpisodeListProps {
    episodes: Episode[];
    currentEpisodeId?: string;
    watchProgress?: Record<string, number>; // episodeId -> progress percentage
}

export default function EpisodeList({
    episodes,
    currentEpisodeId,
    watchProgress = {}
}: EpisodeListProps) {
    if (!episodes.length) return null;

    return (
        <section className="space-y-3">
            <h2 className="text-lg font-bold">Episodes</h2>
            <div className="space-y-3">
                {episodes.map(episode => {
                    const progress = watchProgress[episode.id] || 0;
                    const isWatched = progress >= 90;
                    const isCurrent = episode.id === currentEpisodeId;

                    return (
                        <Link
                            key={episode.id}
                            href={`/watch/${episode.id}`}
                            className={cn(
                                'flex gap-3 p-2 -mx-2 rounded-lg transition-colors',
                                isCurrent
                                    ? 'bg-primary/10 border border-primary/20'
                                    : 'hover:bg-card'
                            )}
                        >
                            {/* Thumbnail */}
                            <div className="relative w-28 sm:w-32 aspect-video flex-shrink-0 rounded-lg overflow-hidden bg-card">
                                <Image
                                    src={episode.thumbnailUrl}
                                    alt={`Episode ${episode.number}`}
                                    fill
                                    className="object-cover"
                                    sizes="128px"
                                />

                                {/* Play overlay */}
                                <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                                    <div className="w-8 h-8 flex items-center justify-center bg-white/90 rounded-full">
                                        <Play size={14} className="fill-black text-black ml-0.5" />
                                    </div>
                                </div>

                                {/* Progress bar */}
                                {progress > 0 && progress < 100 && (
                                    <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/50">
                                        <div
                                            className="h-full bg-primary"
                                            style={{ width: `${progress}%` }}
                                        />
                                    </div>
                                )}

                                {/* Duration badge */}
                                <span className="absolute bottom-1 right-1 px-1 py-0.5 bg-black/70 text-white text-[10px] rounded">
                                    {formatDuration(episode.duration)}
                                </span>
                            </div>

                            {/* Info */}
                            <div className="flex-1 min-w-0 py-1">
                                <div className="flex items-center gap-2">
                                    <p className={cn(
                                        'font-medium text-sm',
                                        isCurrent ? 'text-primary' : 'text-foreground'
                                    )}>
                                        Ep. {episode.number}
                                    </p>
                                    {isWatched && (
                                        <CheckCircle size={14} className="text-green-500" />
                                    )}
                                </div>
                                <p className="text-sm text-foreground line-clamp-1 mt-0.5">
                                    {episode.title}
                                </p>
                                {episode.synopsis && (
                                    <p className="text-xs text-muted-foreground line-clamp-2 mt-1">
                                        {episode.synopsis}
                                    </p>
                                )}
                            </div>
                        </Link>
                    );
                })}
            </div>
        </section>
    );
}
