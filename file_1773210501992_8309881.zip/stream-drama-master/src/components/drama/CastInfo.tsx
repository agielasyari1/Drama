import Image from 'next/image';
import { Star, Calendar, Globe, Tv, Users } from 'lucide-react';
import type { CastMember } from '@/types';

interface CastInfoProps {
    cast: CastMember[];
}

export default function CastInfo({ cast }: CastInfoProps) {
    if (!cast.length) return null;

    return (
        <section className="space-y-3">
            <h2 className="text-lg font-bold flex items-center gap-2">
                <Users size={18} />
                Cast
            </h2>
            <div className="flex gap-4 overflow-x-auto hide-scrollbar pb-2">
                {cast.map(member => (
                    <div key={member.id} className="flex-shrink-0 w-20 text-center">
                        <div className="relative w-16 h-16 mx-auto rounded-full overflow-hidden bg-card">
                            <Image
                                src={member.imageUrl}
                                alt={member.name}
                                fill
                                className="object-cover"
                                sizes="64px"
                            />
                        </div>
                        <p className="mt-2 text-xs font-medium text-foreground line-clamp-1">
                            {member.name}
                        </p>
                        <p className="text-[10px] text-muted-foreground line-clamp-1">
                            {member.role}
                        </p>
                    </div>
                ))}
            </div>
        </section>
    );
}

interface DramaMetaProps {
    year: number;
    country: string;
    episodes: number;
    status: 'ongoing' | 'completed';
    rating: number;
}

export function DramaMeta({ year, country, episodes, status, rating }: DramaMetaProps) {
    return (
        <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-muted-foreground">
            <span className="flex items-center gap-1.5">
                <Star size={14} className="fill-accent text-accent" />
                <span className="font-semibold text-foreground">{rating.toFixed(1)}</span>
            </span>
            <span className="flex items-center gap-1.5">
                <Calendar size={14} />
                {year}
            </span>
            <span className="flex items-center gap-1.5">
                <Globe size={14} />
                {country}
            </span>
            <span className="flex items-center gap-1.5">
                <Tv size={14} />
                {episodes} episodes
            </span>
            <span className={`
        px-2 py-0.5 rounded text-xs font-semibold uppercase
        ${status === 'ongoing' ? 'bg-primary/20 text-primary' : 'bg-secondary text-secondary-foreground'}
      `}>
                {status}
            </span>
        </div>
    );
}
