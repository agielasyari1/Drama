'use client';

import Image from 'next/image';
import Link from 'next/link';
import { Play, Plus, Star, Check } from 'lucide-react';
import Button from '../ui/Button';
import type { Drama } from '@/types';
import { cn, truncate } from '@/lib/utils';
import { useState } from 'react';

interface HeroBannerProps {
    drama: Drama;
    isInMyList?: boolean;
    onToggleMyList?: (id: string) => void;
}

export default function HeroBanner({
    drama,
    isInMyList = false,
    onToggleMyList
}: HeroBannerProps) {
    const [showFullSynopsis, setShowFullSynopsis] = useState(false);

    return (
        <div className="relative w-full aspect-[16/10] sm:aspect-[16/9] overflow-hidden">
            {/* Background Image */}
            <Image
                src={drama.backdropUrl}
                alt={drama.title}
                fill
                className="object-cover"
                priority
                sizes="100vw"
            />

            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />

            {/* Content */}
            <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-6 space-y-3 animate-slideUp">
                {/* Title */}
                <h1 className="text-2xl sm:text-3xl font-bold text-white drop-shadow-lg line-clamp-2">
                    {drama.title}
                </h1>

                {/* Meta info */}
                <div className="flex items-center gap-3 text-sm text-white/80">
                    <span className="flex items-center gap-1">
                        <Star size={14} className="fill-accent text-accent" />
                        <span className="font-semibold">{drama.rating.toFixed(1)}</span>
                    </span>
                    <span>{drama.year}</span>
                    <span>{drama.episodes} episodes</span>
                    <span className={cn(
                        'px-1.5 py-0.5 rounded text-xs font-semibold uppercase',
                        drama.status === 'ongoing' ? 'bg-primary' : 'bg-secondary'
                    )}>
                        {drama.status}
                    </span>
                </div>

                {/* Synopsis */}
                <p
                    className={cn(
                        'text-sm text-white/70 leading-relaxed',
                        !showFullSynopsis && 'line-clamp-2'
                    )}
                    onClick={() => setShowFullSynopsis(!showFullSynopsis)}
                >
                    {drama.synopsis}
                </p>

                {/* Genre Tags */}
                <div className="flex flex-wrap gap-2">
                    {drama.genre.slice(0, 3).map(g => (
                        <span
                            key={g}
                            className="px-2 py-1 bg-white/10 backdrop-blur-sm text-white/90 text-xs rounded-full"
                        >
                            {g}
                        </span>
                    ))}
                </div>

                {/* Action Buttons */}
                <div className="flex items-center gap-3 pt-2">
                    <Link href={`/drama/${drama.id}`}>
                        <Button variant="primary" size="lg" className="gap-2 shadow-lg">
                            <Play size={18} className="fill-white" />
                            Watch Now
                        </Button>
                    </Link>

                    <Button
                        variant="secondary"
                        size="icon"
                        className="h-12 w-12 bg-white/20 backdrop-blur-sm hover:bg-white/30"
                        onClick={() => onToggleMyList?.(drama.id)}
                        aria-label={isInMyList ? 'Remove from My List' : 'Add to My List'}
                    >
                        {isInMyList ? (
                            <Check size={20} className="text-primary" />
                        ) : (
                            <Plus size={20} className="text-white" />
                        )}
                    </Button>
                </div>
            </div>
        </div>
    );
}
