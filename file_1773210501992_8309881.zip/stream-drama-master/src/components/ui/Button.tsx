import React from 'react';
import { cn } from '@/lib/utils';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
    variant?: 'primary' | 'secondary' | 'ghost' | 'outline';
    size?: 'sm' | 'md' | 'lg' | 'icon';
    children: React.ReactNode;
}

export default function Button({
    variant = 'primary',
    size = 'md',
    className,
    children,
    ...props
}: ButtonProps) {
    return (
        <button
            className={cn(
                'inline-flex items-center justify-center font-semibold transition-all duration-200 active:scale-95 disabled:opacity-50 disabled:pointer-events-none touch-target',
                // Variants
                {
                    'bg-primary text-primary-foreground hover:bg-primary/90 shadow-md': variant === 'primary',
                    'bg-secondary text-secondary-foreground hover:bg-secondary/80': variant === 'secondary',
                    'bg-transparent hover:bg-card': variant === 'ghost',
                    'border border-border bg-transparent hover:bg-card': variant === 'outline',
                },
                // Sizes
                {
                    'h-8 px-3 text-sm rounded-md': size === 'sm',
                    'h-10 px-5 text-base rounded-lg': size === 'md',
                    'h-12 px-6 text-lg rounded-xl': size === 'lg',
                    'h-10 w-10 rounded-full p-0': size === 'icon',
                },
                className
            )}
            {...props}
        >
            {children}
        </button>
    );
}
