'use client';

import Image from 'next/image';
import Link from 'next/link';
import { Star, Play } from 'lucide-react';
import type { Drama } from '@/types';
import { cn } from '@/lib/utils';

interface DramaCardProps {
    drama: Drama;
    progress?: number; // 0-100 for continue watching
    showProgress?: boolean;
    size?: 'sm' | 'md' | 'lg';
}

export default function DramaCard({
    drama,
    progress,
    showProgress = false,
    size = 'md'
}: DramaCardProps) {
    const sizeClasses = {
        sm: 'w-24 sm:w-28',
        md: 'w-32 sm:w-36',
        lg: 'w-40 sm:w-44',
    };

    return (
        <Link
            href={`/drama/${drama.id}`}
            className={cn(
                'group flex-shrink-0 snap-start',
                sizeClasses[size]
            )}
        >
            <div className="relative aspect-[2/3] rounded-lg overflow-hidden bg-card shadow-md transition-transform duration-300 group-hover:scale-105">
                {/* Poster Image */}
                <Image
                    src={drama.posterUrl}
                    alt={drama.title}
                    fill
                    className="object-cover"
                    sizes="(max-width: 640px) 128px, 144px"
                    loading="lazy"
                />

                {/* Rating Badge */}
                <div className="absolute top-2 right-2 flex items-center gap-1 bg-black/70 backdrop-blur-sm text-white text-xs font-bold px-1.5 py-0.5 rounded">
                    <Star size={10} className="fill-accent text-accent" />
                    <span>{(drama.rating || 0).toFixed(1)}</span>
                </div>

                {/* Play Icon on Hover */}
                <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="w-12 h-12 flex items-center justify-center bg-primary rounded-full shadow-lg">
                        <Play size={20} className="fill-white text-white ml-1" />
                    </div>
                </div>

                {/* Status Badge */}
                {drama.status === 'ongoing' && (
                    <div className="absolute top-2 left-2 bg-primary text-primary-foreground text-[10px] font-bold px-1.5 py-0.5 rounded uppercase">
                        Ongoing
                    </div>
                )}

                {/* Progress Bar for Continue Watching */}
                {showProgress && progress !== undefined && progress > 0 && (
                    <div className="absolute bottom-0 left-0 right-0 h-1 bg-secondary">
                        <div
                            className="h-full bg-primary transition-all"
                            style={{ width: `${progress}%` }}
                        />
                    </div>
                )}
            </div>

            {/* Title & Meta */}
            <div className="mt-2 space-y-0.5">
                <h3 className="text-sm font-medium text-foreground line-clamp-1 group-hover:text-primary transition-colors">
                    {drama.title}
                </h3>
                <p className="text-xs text-muted-foreground">
                    {drama.year} · {drama.episodes} eps
                </p>
            </div>
        </Link>
    );
}

// Compact card for search results / grids
export function DramaCardCompact({ drama }: { drama: Drama }) {
    return (
        <Link href={`/drama/${drama.id}`} className="group">
            <div className="relative aspect-[2/3] rounded-lg overflow-hidden bg-card shadow-sm">
                <Image
                    src={drama.posterUrl}
                    alt={drama.title}
                    fill
                    className="object-cover transition-transform duration-300 group-hover:scale-105"
                    sizes="(max-width: 640px) 100px, 120px"
                    loading="lazy"
                />
                <div className="absolute top-1 right-1 flex items-center gap-0.5 bg-black/70 text-white text-[10px] font-bold px-1 py-0.5 rounded">
                    <Star size={8} className="fill-accent text-accent" />
                    <span>{(drama.rating || 0).toFixed(1)}</span>
                </div>
            </div>
            <p className="mt-1.5 text-xs font-medium text-foreground line-clamp-2 leading-tight">
                {drama.title}
            </p>
        </Link>
    );
}
