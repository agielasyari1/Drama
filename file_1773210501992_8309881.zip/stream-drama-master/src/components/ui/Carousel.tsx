'use client';

import { useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import DramaCard from './DramaCard';
import type { Drama } from '@/types';
import { cn } from '@/lib/utils';

interface CarouselProps {
    title: string;
    dramas: Drama[];
    showProgress?: boolean;
    className?: string;
}

export default function Carousel({
    title,
    dramas,
    showProgress = false,
    className
}: CarouselProps) {
    const scrollRef = useRef<HTMLDivElement>(null);

    const scroll = (direction: 'left' | 'right') => {
        if (!scrollRef.current) return;

        const scrollAmount = scrollRef.current.clientWidth * 0.8;
        scrollRef.current.scrollBy({
            left: direction === 'left' ? -scrollAmount : scrollAmount,
            behavior: 'smooth',
        });
    };

    if (!dramas.length) return null;

    return (
        <section className={cn('relative', className)}>
            {/* Header */}
            <div className="flex items-center justify-between mb-3 px-4">
                <h2 className="text-lg font-bold text-foreground">{title}</h2>

                {/* Desktop scroll buttons */}
                <div className="hidden sm:flex items-center gap-1">
                    <button
                        onClick={() => scroll('left')}
                        className="p-1.5 rounded-full bg-card hover:bg-secondary transition-colors"
                        aria-label="Scroll left"
                    >
                        <ChevronLeft size={18} />
                    </button>
                    <button
                        onClick={() => scroll('right')}
                        className="p-1.5 rounded-full bg-card hover:bg-secondary transition-colors"
                        aria-label="Scroll right"
                    >
                        <ChevronRight size={18} />
                    </button>
                </div>
            </div>

            {/* Carousel container */}
            <div
                ref={scrollRef}
                className="flex gap-3 overflow-x-auto hide-scrollbar snap-x scroll-pl-4 px-4 pb-2"
            >
                {dramas.map((drama, index) => (
                    <DramaCard
                        key={drama.id}
                        drama={drama}
                        showProgress={showProgress}
                        progress={showProgress ? (drama as Drama & { progress?: number }).progress : undefined}
                    />
                ))}

                {/* Spacer for end padding */}
                <div className="flex-shrink-0 w-1" aria-hidden="true" />
            </div>
        </section>
    );
}
