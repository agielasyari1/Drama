import { cn } from '@/lib/utils';

interface SkeletonProps {
    className?: string;
}

export function Skeleton({ className }: SkeletonProps) {
    return (
        <div
            className={cn(
                'animate-shimmer rounded-lg',
                className
            )}
        />
    );
}

export function DramaCardSkeleton() {
    return (
        <div className="flex-shrink-0 w-32 sm:w-36 snap-start">
            <Skeleton className="aspect-[2/3] w-full rounded-lg" />
            <Skeleton className="h-4 w-3/4 mt-2 rounded" />
            <Skeleton className="h-3 w-1/2 mt-1 rounded" />
        </div>
    );
}

export function CarouselSkeleton() {
    return (
        <div className="space-y-3">
            <Skeleton className="h-6 w-32 rounded" />
            <div className="flex gap-3 overflow-hidden">
                {Array.from({ length: 4 }).map((_, i) => (
                    <DramaCardSkeleton key={i} />
                ))}
            </div>
        </div>
    );
}

export function HeroBannerSkeleton() {
    return (
        <div className="relative w-full aspect-[16/10] sm:aspect-[16/9]">
            <Skeleton className="absolute inset-0" />
            <div className="absolute bottom-0 left-0 right-0 p-4 space-y-3">
                <Skeleton className="h-8 w-2/3 rounded" />
                <Skeleton className="h-4 w-full rounded" />
                <Skeleton className="h-4 w-3/4 rounded" />
                <div className="flex gap-3 pt-2">
                    <Skeleton className="h-10 w-24 rounded-full" />
                    <Skeleton className="h-10 w-10 rounded-full" />
                </div>
            </div>
        </div>
    );
}

export function EpisodeListSkeleton() {
    return (
        <div className="space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="flex gap-3">
                    <Skeleton className="w-32 aspect-video rounded-lg flex-shrink-0" />
                    <div className="flex-1 space-y-2 py-1">
                        <Skeleton className="h-4 w-full rounded" />
                        <Skeleton className="h-3 w-2/3 rounded" />
                    </div>
                </div>
            ))}
        </div>
    );
}

export function SearchResultsSkeleton() {
    return (
        <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
            {Array.from({ length: 9 }).map((_, i) => (
                <DramaCardSkeleton key={i} />
            ))}
        </div>
    );
}
