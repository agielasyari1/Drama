'use client';

import { usePathname } from 'next/navigation';
import Link from 'next/link';
import { Home, Search, Bookmark, User } from 'lucide-react';
import { cn } from '@/lib/utils';

const navItems = [
    { href: '/', icon: Home, label: 'Home' },
    { href: '/search', icon: Search, label: 'Search' },
    { href: '/my-list', icon: Bookmark, label: 'My List' },
    { href: '/profile', icon: User, label: 'Profile' },
];

export default function BottomNav() {
    const pathname = usePathname();

    // Hide on video player page
    if (pathname.startsWith('/watch')) {
        return null;
    }

    return (
        <nav className="fixed bottom-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-lg border-t border-border safe-bottom">
            <div className="flex items-center justify-around h-16 max-w-lg mx-auto px-4">
                {navItems.map(({ href, icon: Icon, label }) => {
                    const isActive = pathname === href || (href !== '/' && pathname.startsWith(href));

                    return (
                        <Link
                            key={href}
                            href={href}
                            className={cn(
                                'touch-target flex flex-col items-center gap-1 transition-colors duration-200',
                                isActive
                                    ? 'text-primary'
                                    : 'text-muted-foreground hover:text-foreground'
                            )}
                        >
                            <Icon
                                size={24}
                                strokeWidth={isActive ? 2.5 : 2}
                                className={cn(
                                    'transition-transform duration-200',
                                    isActive && 'scale-110'
                                )}
                            />
                            <span className={cn(
                                'text-xs font-medium',
                                isActive ? 'text-primary' : 'text-muted-foreground'
                            )}>
                                {label}
                            </span>
                        </Link>
                    );
                })}
            </div>
        </nav>
    );
}
